// 来源：REA 导出的公开生产脚本。仅格式化，保留打包模块与混淆变量；不是可独立运行的源码工程。
"use strict";
(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[4782],{
  2299:(e,t,r)=>{
    r.d(t,{
      $:()=>l,r:()=>c}
    );
    var a=r(38942),n=r(42062),i=r(66938),o=r(56559),s=r(85832);
    let c=(0,o.F)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl text-sm font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",{
      variants:{
        variant:{
          default:"bg-primary text-primary-foreground shadow-[0_10px_24px_-16px_rgba(70,44,28,0.8)] hover:-translate-y-0.5 hover:bg-primary/90 hover:shadow-md",destructive:"bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",outline:"border border-input bg-card/65 shadow-sm hover:border-primary/25 hover:bg-secondary hover:text-secondary-foreground",secondary:"bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",ghost:"hover:bg-secondary hover:text-secondary-foreground",link:"text-primary underline-offset-4 hover:underline",quiet:"border border-border/70 bg-secondary/70 text-secondary-foreground hover:bg-secondary"}
        ,size:{
          default:"min-h-11 px-4 py-2.5",sm:"min-h-9 rounded-lg px-3 text-xs",lg:"min-h-12 rounded-xl px-7 py-3 text-base",icon:"h-11 w-11 rounded-full"}
        }
      ,defaultVariants:{
        variant:"default",size:"default"}
      }
    ),l=n.forwardRef((e,t)=>{
      let{
        className:r,variant:n,size:o,asChild:l=!1,...d}
      =e,u=l?i.DX:"button";
      return(0,a.jsx)(u,{
        className:(0,s.cn)(c({
          variant:n,size:o,className:r}
        )),ref:t,...d}
      )}
    );
    l.displayName="Button"}
  ,30968:(e,t,r)=>{
    r.d(t,{
      $4:()=>z,AO:()=>f,CO:()=>k,Dq:()=>A,Q:()=>C,Re:()=>R,WF:()=>E,XC:()=>g,_2:()=>p,hL:()=>T,kv:()=>m,ln:()=>_,oA:()=>v,pX:()=>w,qO:()=>S,ry:()=>b,v0:()=>y,wH:()=>P}
    );
    var a=r(36187),n=r(70693),i=r(33366),o=r(38685),s=r(60272),c=r(85800);
    function l(e){
      let t="string"==typeof e?e.trim():"";
      if(t&&!(t.length>100))return/^qa_[a-z0-9_]+$/i.test(t)?t:void 0}
    function d(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"qa",r=l(null==e?void 0:e.requestId)||function(){
        let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"qa";
        return"".concat(e,"_").concat(Date.now(),"_").concat(Math.random().toString(36).slice(2,10))}
      (t);
      return{
        ...e,requestId:r}
      }
    let u="__tjyActiveSSEConnections";
    function h(e){
      let t=window,r=Math.max(0,(t[u]||0)+e);
      t[u]=r,window.dispatchEvent(new CustomEvent("tjy:sse-activity-change",{
        detail:{
          active:r>0,count:r}
        }
      ))}
    async function f(e){
      var t,r,d;
      let u,f=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,y=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{
        }
      ,{
        onConnected:v,onChunk:m,onThinking:p,onCompleted:w,onError:g,onMeta:b}
      =y,_=f.serviceType||(0,a.he)(e),T=(null==(t=f.body)?void 0:t.locale)||(window.location.pathname.startsWith("/zh-TW")||window.location.pathname.startsWith("/zh-tw")||window.location.pathname.startsWith("/zh-HK")||window.location.pathname.startsWith("/zh-hk")||"zh-TW"===document.documentElement.lang?"zh-TW":void 0),k="zh-TW"===T||"zh-tw"===T||"zh-HK"===T||"zh-hk"===T||"zh-Hant"===T;
      if(f.body&&"object"==typeof f.body&&!f.body.locale&&T&&(f.body.locale=T),(null==(d=f.headers)||null==(r=d.Authorization)?void 0:r.startsWith("Bearer "))&&!f.skipCreditCheck)try{
        let e=(0,a.W2)(_),t=(0,i.z4)(e);
        if(!await (0,i.IE)(e,t)){
          let e=Error("积分不足：".concat(t,"需要足够积分才能使用"));
          throw e.type="INSUFFICIENT_CREDITS",e}
        }
      catch(e){
        if("INSUFFICIENT_CREDITS"===e.type)return null==g||g(e.message),""}
      else f.skipCreditCheck;
      let A=0,C="",E=!1,P=()=>{
        var e,t;
        (null==(t=f.headers)||null==(e=t.Authorization)?void 0:e.startsWith("Bearer "))&&(0,n.St)()}
      ,S=e=>{
        if(!e||e===C)return;
        let t=k?(0,s.bb)(String(e)):String(e),r=t.startsWith(C)?t.slice(C.length):t;
        C=t,r&&(null==m||m(r))}
      ,z=async()=>new Promise((t,r)=>{
        var n;
        let d=null,h=l(null==(n=f.body)?void 0:n.requestId);
        fetch((0,c.c_)(e),{
          method:f.method||"POST",headers:{
            "Content-Type":"application/json",Accept:"text/event-stream",...h?{
              "X-Reading-Request-Id":h}
            :{
              }
            ,...f.headers}
          ,body:f.body?JSON.stringify(f.body):void 0}
        ).then(async n=>{
          if(!n.ok){
            let t="HTTP ".concat(n.status,": ").concat(n.statusText),r="HTTP_ERROR";
            try{
              let o=n.headers.get("content-type");
              if(null==o?void 0:o.includes("application/json")){
                let o=await n.json();
                if(o.error&&(t=o.error),o.error_type&&(r=o.error_type),"INSUFFICIENT_CREDITS"===r){
                  let r=(0,a.W2)(f.serviceType||(0,a.he)(e));
                  (0,i.J1)({
                    requiredCredits:Number(o.required_credits||0),availableCredits:Number(o.available_credits||0),serviceName:(0,i.z4)(r),serviceType:r}
                  );
                  let n=Error(t);
                  throw n.type="INSUFFICIENT_CREDITS",n.skipToast=!0,n}
                }
              }
            catch(e){
              if("INSUFFICIENT_CREDITS"===e.type)throw e}
            let o=Error(t);
            throw o.type=r,o}
          if(!n.body)throw Error("Response body is not available");
          let c=n.body.getReader(),l=new TextDecoder,h=()=>{
            d&&(clearTimeout(d),d=null)}
          ,y=()=>{
            try{
              h(),c&&c.releaseLock()}
            catch(e){
              }
            }
          ,T=async(r,a,n)=>{
            let i=k?(0,s.bb)(r):r,c=a||u;
            if(!E){
              var l,d,h,v;
              if(E=!0,y(),null==w||w(i,c,n),(null==i?void 0:i.trim())&&(null==(d=f.headers)||null==(l=d.Authorization)?void 0:l.startsWith("Bearer "))&&setTimeout(()=>{
                (0,o.$)({
                  apiPath:e,serviceType:_,questionId:c,contentLength:i.length}
                )}
              ,0),c&&(null==(v=f.headers)||null==(h=v.Authorization)?void 0:h.startsWith("Bearer ")))try{
                P()}
              catch(e){
                }
              }
            t(i)}
          ,A="",S="",z="";
          !function e(){
            c.read().then(t=>{
              let{
                done:a,value:n}
              =t;
              if(a){
                S&&z&&(o(S,z),S="",z=""),T(C);
                return}
              let i=(A+l.decode(n,{
                stream:!0}
              )).split("\n");
              function o(e,t){
                try{
                  let n=JSON.parse(t);
                  switch(n.questionId&&(u=n.questionId),e){
                    case"connected":null==v||v();
                    break;
                    case"meta":"meta"===n.type&&(null==b||b(n.payload,n.questionId));
                    break;
                    case"thinking":if(n.content){
                      let e=k?(0,s.bb)(n.content):n.content;
                      null==p||p(e)}
                    break;
                    case"data":if(n.content){
                      let e=k?(0,s.bb)(n.content):n.content;
                      C+=e,null==m||m(e)}
                    break;
                    case"completed":var a;
                    "string"==typeof n.content&&(C=k?(0,s.bb)(n.content):n.content);
                    let i={
                      finishReason:null!=(a=n.finishReason)?a:null,truncated:!!n.truncated}
                    ;
                    T(C,n.questionId,i);
                    return;
                    case"error":y(),null==g||g(n.message||"Unknown error"),r(Error(n.message||"SSE stream error"));
                    return}
                  }
                catch(e){
                  }
                }
              for(let e of(A=i.pop()||"",i)){
                let t=e.trim();
                if(t.startsWith("event: "))S&&z&&o(S,z),S=t.slice(7).trim(),z="";
                else if(t.startsWith("data: ")){
                  let e=t.slice(6);
                  z=z?z+"\n"+e:e}
                else""===t&&S&&z&&(o(S,z),S="",z="")}
              E||e()}
            ).catch(e=>{
              try{
                h(),c&&c.releaseLock()}
              catch(e){
                }
              E||r(e)}
            )}
          ()}
        ).catch(e=>{
          d&&(clearTimeout(d),d=null),E||r(e)}
        ),f.timeout&&(d=setTimeout(()=>{
          E||(E=!0,r(Error("SSE connection timeout")))}
        ,f.timeout))}
      ),R=async()=>{
        if(!u)return{
          status:"processing"}
        ;
        try{
          var e;
          let t="/api/reading-recovery?questionId=".concat(encodeURIComponent(u)),r={
            }
          ;
          (null==(e=f.headers)?void 0:e.Authorization)&&(r.Authorization=f.headers.Authorization);
          for(let e=0;
          e<3;
          e++){
            e>0&&await new Promise(e=>setTimeout(e,5e3));
            let a=await fetch((0,c.c_)(t),{
              headers:r}
            );
            if(!a.ok)continue;
            let n=await a.json();
            if("completed"===n.status&&n.content)return S(n.content),E=!0,null==w||w(C,u),P(),{
              status:"completed",content:C}
            ;
            if("failed"===n.status)return{
              status:"failed",message:n.message}
            ;
            if("partial"===n.status&&n.content&&S(n.content),"processing"===n.status)return{
              status:"processing",message:"string"==typeof n.message?n.message:void 0}
            }
          }
        catch(e){
          }
        return{
          status:"processing"}
        }
      ,I=async()=>{
        try{
          return await z()}
        catch(t){
          if(E)return C;
          if(u){
            let e=await R();
            if("completed"===e.status)return e.content||C;
            let t="failed"===e.status?"AI分析生成失败，请稍后重试。":"暂未查询到可恢复结果，请稍后重试"===e.message?"请求可能未成功提交，请检查网络后重试。":"AI分析连接中断，结果可能在后台完成。请刷新页面查看历史记录。";
            throw null==g||g(t),Error(t)}
          let e=function(e){
            var t;
            let r=(null==(t=e.message)?void 0:t.toLowerCase())||"";
            return["network","connection","timeout","econnreset","enotfound","fetch failed","load failed"].some(e=>r.includes(e))||"NetworkError"===e.name||"TypeError"===e.name&&r.includes("fetch")}
          (t);
          if(A<2&&e&&!E){
            let e=2e3*Math.pow(1.5,++A-1);
            return null==g||g("连接中断，正在重试... (".concat(A,"/").concat(2,")")),await new Promise(t=>setTimeout(t,e)),I()}
          if(!E&&"INSUFFICIENT_CREDITS"!==t.type){
            let e="SSE连接失败: ".concat(t.message);
            null==g||g(e)}
          throw t}
        }
      ;
      h(1);
      try{
        return await I()}
      finally{
        h(-1)}
      }
    async function y(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/divination",{
        method:"POST",headers:a,body:d(e),timeout:3e5}
      ,t)}
    async function v(e){
      var t;
      let a=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,n={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(n.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/tarot",{
        method:"POST",headers:n,body:d({
          ...e,spreadMode:null!=(t=e.spreadMode)?t:e.threeCardMode}
        ),timeout:3e5}
      ,a)}
    async function m(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/bazi",{
        method:"POST",headers:a,body:d(e),timeout:3e5}
      ,t)}
    async function p(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/bazi-follow-up",{
        method:"POST",headers:a,body:d(e),timeout:18e4,serviceType:"bazi"}
      ,t)}
    async function w(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/forecast-weekly-ai",{
        method:"POST",headers:a,body:d(e),timeout:18e4}
      ,t)}
    async function g(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/forecast-monthly-ai",{
        method:"POST",headers:a,body:d(e),timeout:18e4,serviceType:"forecast-monthly-ai"}
      ,t)}
    async function b(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/forecast-daily-ai",{
        method:"POST",headers:a,body:d(e),timeout:18e4}
      ,t)}
    async function _(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/daily-sign/interpret",{
        method:"POST",headers:a,body:d(e),timeout:18e4,serviceType:"daily-sign"}
      ,t)}
    async function T(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/dream",{
        method:"POST",headers:a,body:d(e),timeout:3e5}
      ,t)}
    async function k(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/naming",{
        method:"POST",headers:a,body:d(e),timeout:3e5}
      ,t)}
    async function A(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/company-naming",{
        method:"POST",headers:a,body:d(e),timeout:3e5}
      ,t)}
    async function C(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/ziwei-ai",{
        method:"POST",headers:a,body:d(e),timeout:3e5}
      ,t)}
    async function E(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/ziwei-follow-up",{
        method:"POST",headers:a,body:d(e),timeout:18e4,serviceType:"ziwei"}
      ,t)}
    async function P(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a=arguments.length>2?arguments[2]:void 0,n={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(n.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/hepan/".concat(e,"/analyze"),{
        method:"POST",headers:n,body:a?{
          hepan_type:a}
        :{
          }
        ,timeout:3e5,serviceType:a?"hepan-".concat(a):"hepan-love"}
      ,t)}
    async function S(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/forecast-yearly-ai",{
        method:"POST",headers:a,body:d({
          ...e,year:e.year||2026}
        ),timeout:3e5,serviceType:"forecast-yearly-ai"}
      ,t)}
    async function z(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/divination-follow-up",{
        method:"POST",headers:a,body:d(e),timeout:3e5,serviceType:"divination-follow-up"}
      ,t)}
    async function R(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,a={
        }
      ;
      try{
        let{
          authClient:e}
        =await Promise.resolve().then(r.bind(r,69395)),t=await e.getValidAccessToken();
        t&&(a.Authorization="Bearer ".concat(t))}
      catch(e){
        }
      return f("/api/offer-match",{
        method:"POST",headers:a,body:d(e),timeout:24e4,serviceType:"offer-match"}
      ,t)}
    }
  ,33366:(e,t,r)=>{
    r.d(t,{
      IE:()=>l,J1:()=>s,UA:()=>o,aM:()=>c,z4:()=>u}
    );
    var a=r(99215);
    let n=!1,i=null;
    function o(e){
      i=e}
    function s(e){
      if(!n)if(n=!0,i)i(!0,e);
      else{
        let t="积分不足！\n需要: ".concat(e.requiredCredits,"积分\n当前: ").concat(e.availableCredits,"积分\n服务: ").concat(e.serviceName);
        !e.isPro&&e.originalPrice&&(t+="\n\n\uD83D\uDC8E 开通Pro会员仅需1积分！\n立省".concat(e.requiredCredits-1,"积分")),alert(t),n=!1}
      }
    function c(){
      n=!1,i&&i(!1)}
    async function l(e,t){
      try{
        let r=await (0,a.W8)(e);
        if(!r.canAfford){
          if(!r.error&&r.requiredCredits>0)return s({
            requiredCredits:r.requiredCredits,availableCredits:r.availableCredits,serviceName:t,serviceType:e,isPro:r.isPro,originalPrice:r.originalPrice,discountSaved:r.discountSaved}
          ),!1;
          return!0}
        return r.isPro&&r.originalPrice,!0}
      catch(e){
        return!0}
      }
    let d={
      divination_general:"易经占卜",divination_tarot:"塔罗占卜",divination_bazi:"八字算命",divination_ziwei:"紫微斗数",divination_naming:"起名服务",divination_dream:"梦境解析",divination_company_naming:"公司起名",weekly_forecast_ai:"周运势AI分析",destiny_chat_turn:"命理对话",offer_match:"岗位与 Offer 契合度测评","offer-match":"岗位与 Offer 契合度测评"}
    ;
    function u(e){
      return d[e]||e}
    }
  ,36187:(e,t,r)=>{
    r.d(t,{
      W2:()=>n,he:()=>i}
    );
    let a={
      divination:"divination_general",tarot:"divination_tarot","tarot-three":"divination_tarot_three","tarot-celtic":"divination_tarot_celtic",bazi:"divination_bazi",dream:"divination_dream",ziwei:"divination_ziwei",naming:"divination_naming","company-naming":"company_naming","daily-divination":"daily_fortune","forecast-weekly-ai":"weekly_forecast_ai","forecast-daily-ai":"daily_forecast_ai","forecast-yearly-ai":"yearly_forecast_ai","forecast-monthly-ai":"monthly_forecast_ai",monthly_forecast_ai:"monthly_forecast_ai","daily-sign":"daily_sign_ai",daily_sign_ai:"daily_sign_ai",chat:"destiny_chat_turn","destiny-chat":"destiny_chat_turn",destiny_chat_turn:"destiny_chat_turn","hepan-love":"hepan_love","hepan-business":"hepan_business","offer-match":"offer_match",offer_match:"offer_match"}
    ;
    function n(e){
      return a[e]||"general_service"}
    function i(e){
      let t=e.replace(/^\/api\//,"");
      return t.startsWith("hepan/")?"hepan-love":({
        divination:"divination",tarot:"tarot",bazi:"bazi",dream:"dream","ziwei-ai":"ziwei",naming:"naming","company-naming":"company-naming","offer-match":"offer-match","daily-divination":"daily-divination","forecast-weekly-ai":"forecast-weekly-ai","forecast-daily-ai":"forecast-daily-ai","forecast-yearly-ai":"forecast-yearly-ai","forecast-monthly-ai":"forecast-monthly-ai","daily-sign/interpret":"daily-sign",chat:"chat"}
      )[t]||t}
    }
  ,38685:(e,t,r)=>{
    r.d(t,{
      $:()=>s,g:()=>n}
    );
    var a=r(36187);
    let n="tjy:pro-membership-nudge-completed",i=new Set(["divination_general","divination_tarot","divination_tarot_three","divination_tarot_celtic","divination_bazi","divination_ziwei","divination_dream","daily_fortune","daily_forecast_ai","weekly_forecast_ai","monthly_forecast_ai","yearly_forecast_ai","destiny_chat_turn","hepan_love","hepan_business","hepan_general"]),o=["divination","tarot","bazi","ziwei","dream","daily-divination","forecast-","chat","destiny","hepan"];
    function s(e){
      let{
        apiPath:t,serviceType:r,questionId:s,contentLength:c}
      =e,l=r||(0,a.he)(t),d=(0,a.W2)(l);
      (i.has(d)||o.some(e=>l.startsWith(e)))&&window.dispatchEvent(new CustomEvent(n,{
        detail:{
          serviceType:l,creditType:d,apiPath:t,questionId:s,contentLength:c}
        }
      ))}
    }
  ,70693:(e,t,r)=>{
    r.d(t,{
      I:()=>l,St:()=>d}
    );
    var a=r(24333),n=r(94190),i=r(94970),o=r(42062);
    let s=async(e,t)=>{
      let{
        authClient:a}
      =await Promise.resolve().then(r.bind(r,69395));
      if(a.isTokenExpired()&&!await a.refreshToken())throw Error("认证已过期，请重新登录");
      let n=t(),i=await fetch(e,{
        headers:n}
      );
      if(401===i.status){
        var o,s,c;
        let r=await i.json();
        if((null==(o=r.error)?void 0:o.includes("token"))||(null==(s=r.error)?void 0:s.includes("unauthorized"))||(null==(c=r.error)?void 0:c.includes("expired")))if(await a.refreshToken())n=t(),i=await fetch(e,{
          headers:n}
        );
        else throw Error(r.error||"认证失败")}
      let l=await i.json();
      if(!l.success)throw Error(l.error||"请求失败");
      return l}
    ,c={
      BALANCE:"/api/credits/balance",HISTORY:"/api/credits/history",STATUS:"/api/credits/status",RULES:"/api/credits/rules"}
    ;
    function l(){
      let{
        user:e,getAuthHeaders:t}
      =(0,i.A)(),l=(0,o.useRef)(!1),d=(0,o.useRef)(!1);
      (0,o.useEffect)(()=>{
        if("undefined"==typeof document)return;
        let t=async()=>{
          if(!d.current&&!document.hidden&&e){
            d.current=!0;
            try{
              let{
                authClient:e}
              =await Promise.resolve().then(r.bind(r,69395));
              e.isTokenExpired()&&await e.refreshToken()&&(0,a.j)(e=>"string"==typeof e&&e.startsWith("/api/credits"),void 0,{
                revalidate:!0}
              )}
            catch(e){
              }
            finally{
              d.current=!1}
            }
          }
        ;
        return document.addEventListener("visibilitychange",t),window.addEventListener("focus",t),e&&!l.current&&(l.current=!0,t()),()=>{
          document.removeEventListener("visibilitychange",t),window.removeEventListener("focus",t)}
        }
      ,[e]);
      let u=(0,o.useCallback)(e=>s(e,t),[t]),h=(0,o.useCallback)(e=>s(e,t),[t]),{
        data:f,error:y,isLoading:v,mutate:m}
      =(0,n.Ay)(e?c.BALANCE:null,u,{
        refreshInterval:3e4,revalidateOnFocus:!1,revalidateOnReconnect:!0,dedupingInterval:2e3,shouldRetryOnError:!0,errorRetryCount:2,errorRetryInterval:1e3,onError:e=>{
          }
        }
      ),{
        data:p,mutate:w}
      =(0,n.Ay)(e?c.STATUS:null,h,{
        revalidateOnFocus:!1,revalidateOnReconnect:!0,dedupingInterval:2e3,shouldRetryOnError:!0,errorRetryCount:2,errorRetryInterval:1e3,onError:e=>{
          }
        }
      ),{
        data:g}
      =(0,n.Ay)(c.RULES,e=>s(e,()=>({
        }
      ))),b=(0,o.useCallback)(async function(){
        let r=arguments.length>0&&void 0!==arguments[0]?arguments[0]:1,a=arguments.length>1&&void 0!==arguments[1]?arguments[1]:20;
        if(!e)return{
          transactions:[],page:1,limit:20,total:0}
        ;
        try{
          let e=t(),n=await fetch("".concat(c.HISTORY,"?page=").concat(r,"&limit=").concat(a),{
            headers:e}
          ),i=await n.json();
          if(i.success)return i;
          throw Error(i.error)}
        catch(e){
          return{
            transactions:[],page:1,limit:20,total:0}
          }
        }
      ,[e,t]),_=(0,o.useCallback)(async()=>{
        if(!e)return{
          success:!1,error:"请先登录",consecutive_days:0,base_credits:0,bonus_credits:0,total_credits:0,new_balance:0,message:""}
        ;
        try{
          let e=t(),r=await fetch("/api/credits/checkin",{
            method:"POST",headers:e}
          ),a=await r.json();
          return a.success&&(m(),w()),a}
        catch(e){
          return{
            success:!1,error:"签到失败",consecutive_days:0,base_credits:0,bonus_credits:0,total_credits:0,new_balance:0,message:""}
          }
        }
      ,[e,t,m,w]),T=(0,o.useCallback)(async(r,a,n,i)=>{
        if(!e)return{
          success:!1,error:"请先登录"}
        ;
        try{
          let e={
            ...t(),"Content-Type":"application/json"}
          ,o=await fetch("/api/credits/spend",{
            method:"POST",headers:e,body:JSON.stringify({
              action_type:r,amount:a,description:n,metadata:i}
            )}
          ),s=await o.json();
          return s.success&&m(),s}
        catch(e){
          return{
            success:!1,error:"积分消费失败"}
          }
        }
      ,[e,t,m]),k=(0,o.useRef)(null);
      k.current=g;
      let A=(0,o.useCallback)(async()=>{
        var e;
        if(null==(e=k.current)?void 0:e.rules)return k.current.rules;
        try{
          let e=await fetch(c.RULES),t=await e.json();
          if(t.success)return t.rules;
          throw Error(t.error)}
        catch(e){
          return[]}
        }
      ,[]),C=(0,o.useCallback)(async function(){
        let e=arguments.length>0&&void 0!==arguments[0]&&arguments[0];
        e&&await m()}
      ,[m]);
      return{
        balance:null==f?void 0:f.credits,checkinStatus:null==p?void 0:p.data,loading:v,error:y,fetchBalance:C,fetchHistory:b,checkin:_,spendCredits:T,fetchRules:A}
      }
    function d(){
      (0,a.j)(e=>Array.isArray(e)&&e[0]===c.BALANCE,void 0,{
        revalidate:!0}
      )}
    }
  ,85800:(e,t,r)=>{
    r.d(t,{
      J_:()=>s,c_:()=>d,hQ:()=>n,hY:()=>l,lB:()=>o}
    );
    var a=r(27239);
    function n(){
      var e,t,r,a,n;
      let i=null==(e=window)?void 0:e.Capacitor;
      return"function"==typeof(null==i?void 0:i.isNativePlatform)?i.isNativePlatform():void 0!==(null==(t=window)?void 0:t.androidBridge)||void 0!==(null==(n=window)||null==(a=n.webkit)||null==(r=a.messageHandlers)?void 0:r.bridge)||"capacitor:"===window.location.protocol||("localhost"===window.location.hostname||"127.0.0.1"===window.location.hostname)&&(""===window.location.port||void 0!==i&&null!=i&&!!i.Plugins)}
    function i(){
      var e,t,r,a,i;
      let o=null==(e=window)?void 0:e.Capacitor;
      if("function"==typeof(null==o?void 0:o.getPlatform)){
        let e=o.getPlatform();
        if("android"===e||"ios"===e)return e}
      if(void 0!==(null==(t=window)?void 0:t.androidBridge))return"android";
      if(void 0!==(null==(i=window)||null==(a=i.webkit)||null==(r=a.messageHandlers)?void 0:r.bridge))return"ios";
      if(n()){
        let e=("undefined"!=typeof navigator?navigator.userAgent:"").toLowerCase();
        if(e.includes("android"))return"android";
        if(e.includes("iphone")||e.includes("ipad")||e.includes("ipod"))return"ios"}
      return"web"}
    function o(){
      return"android"===i()}
    function s(){
      return"ios"===i()}
    let c="https://tianjiyao.com";
    function l(){
      return a.env.NEXT_PUBLIC_API_BASE_URL?a.env.NEXT_PUBLIC_API_BASE_URL.replace(/\/+$/,""):n()?c:""}
    function d(e){
      if(!e)return"";
      if(e.startsWith("http://")||e.startsWith("https://"))return e;
      let t=l(),r=e.startsWith("/")?e:"/".concat(e);
      return"".concat(t).concat(r)}
    !function(){
      let e=window;
      if(e.__tjyNativeFetchPatched)return;
      e.__tjyNativeFetchPatched=!0;
      let t=window.fetch;
      window.fetch=function(e,r){
        let a=("localhost"===window.location.hostname||"127.0.0.1"===window.location.hostname)&&(""===window.location.port||"capacitor:"===window.location.protocol);
        if(n()||a){
          if("string"==typeof e)e.startsWith("/api/")&&(e="".concat(c).concat(e));
          else if(e instanceof URL)e.pathname.startsWith("/api/")&&("localhost"===e.hostname||"127.0.0.1"===e.hostname)&&(e=new URL("".concat(c).concat(e.pathname).concat(e.search)));
          else if("undefined"!=typeof Request&&e instanceof Request){
            let t=new URL(e.url);
            t.pathname.startsWith("/api/")&&("localhost"===t.hostname||"127.0.0.1"===t.hostname)&&(e=new Request("".concat(c).concat(t.pathname).concat(t.search),e))}
          }
        return t.call(this,e,r)}
      }
    ()}
  ,85832:(e,t,r)=>{
    r.d(t,{
      Dk:()=>s,cn:()=>o}
    );
    var a=r(94631),n=r(75110),i=r(85800);
    function o(){
      for(var e=arguments.length,t=Array(e),r=0;
      r<e;
      r++)t[r]=arguments[r];
      return(0,n.QP)((0,a.$)(t))}
    async function s(e){
      try{
        let t=await fetch((0,i.c_)("/api/qa-records?action=get&id=".concat(e)));
        if(!t.ok)throw Error("HTTP error! status: ".concat(t.status));
        let r=await t.json();
        if(r.success&&r.data)return r.data.answer||null;
        return null}
      catch(e){
        return null}
      }
    }
  ,86503:(e,t,r)=>{
    r.d(t,{
      $0:()=>y,$P:()=>m,AT:()=>f,H2:()=>v,Kq:()=>i.Kq,Vg:()=>p}
    );
    var a=r(93578),n=r(85800),i=r(89257),o=r(69395);
    let s=async()=>await o.authClient.refreshToken()?o.authClient.getAccessToken():null,c=()=>o.authClient.getValidAccessToken();
    async function l(){
      try{
        if(c)return await c();
        let e=localStorage.getItem("auth_session");
        if(e){
          let t=JSON.parse(e);
          return(null==t?void 0:t.access_token)||null}
        }
      catch(e){
        }
      return null}
    function d(e,t){
      let r=arguments.length>2&&void 0!==arguments[2]&&arguments[2],a=new Headers(e.headers);
      return(r||!a.has("Authorization"))&&a.set("Authorization","Bearer ".concat(t)),{
        ...e,headers:a}
      }
    let u=(()=>{
      let e=a.A.create({
        baseURL:(0,n.hY)(),timeout:3e4,headers:{
          "Content-Type":"application/json"}
        }
      );
      return e.interceptors.request.use(async e=>{
        let t=await l();
        return t&&!e.headers.Authorization&&(e.headers.Authorization="Bearer ".concat(t)),e}
      ,e=>Promise.reject(e)),e.interceptors.response.use(e=>e,async t=>{
        var r,a,n,o;
        let c=t.config;
        if((null==(r=t.response)?void 0:r.status)===401&&c&&!c._authRetried&&s){
          c._authRetried=!0;
          let t=await s();
          if(t)return c.headers=c.headers||{
            }
          ,c.headers.Authorization="Bearer ".concat(t),e(c)}
        let l=null==(n=null==(a=t.config)?void 0:a.showLoginOnAuthError)||n;
        if(t.response&&l){
          let e={
            status:t.response.status,url:(null==(o=t.config)?void 0:o.url)||"unknown",ok:!1}
          ;
          (0,i.tu)(e,t.response.data)}
        return Promise.reject(t)}
      ),e}
    )();
    async function h(e){
      let t,r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:3,a=arguments.length>2&&void 0!==arguments[2]?arguments[2]:1e3;
      for(let n=1;
      n<=r;
      n++)try{
        return await e()}
      catch(e){
        if(t=e,n===r)throw e;
        if(function(e){
          var t;
          let r=(null==(t=e.message)?void 0:t.toLowerCase())||"",a=e.code||e.status||0;
          for(let e of["unauthorized","forbidden","invalid api key","api key","quota exceeded","billing","payment","subscription","model not found","invalid model","bad request"])if(r.includes(e))return!1;
          return![400,401,403,404].includes(a)&&!!(["network","timeout","connection","econnreset","enotfound","socket hang up","fetch failed","dns"].some(e=>r.includes(e))||[429,500,502,503,504,520,521,522,523,524].includes(a))}
        (e))await new Promise(e=>setTimeout(e,a*n));
        else throw e}
      throw t}
    async function f(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,r=Date.now(),a=0;
      try{
        let n=await h(async()=>(a++,(await u({
          url:e,...t}
        )).data),t.retries||3,t.retryDelay||1e3),i=Date.now()-r;
        return{
          success:!0,data:n,processingTime:i,retryCount:a-1}
        }
      catch(t){
        let e=Date.now()-r;
        return{
          success:!1,error:t.message||"Unknown error",errorType:t.code||t.status||"UNKNOWN",processingTime:e,retryCount:a-1}
        }
      }
    async function y(e){
      try{
        let t=await m("/api/validate-question",e),r=await t.json();
        return{
          success:t.ok,data:r,error:r.error,errorType:r.errorType}
        }
      catch(e){
        return{
          success:!1,error:e.message||"Unknown error",errorType:"NETWORK_ERROR"}
        }
      }
    async function v(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,r=!(arguments.length>2)||void 0===arguments[2]||arguments[2],a=!(arguments.length>3)||void 0===arguments[3]||arguments[3],o=t;
      if(a){
        let e=await l();
        e&&(o=d(t,e))}
      let c=(0,n.c_)(e),u=await fetch(c,o);
      if(401===u.status&&a&&s){
        let e=await s();
        e&&(o=d(t,e,!0),u=await fetch(c,o))}
      if(!u.ok&&r)try{
        let e=await u.clone().json();
        (0,i.tu)(u,e)}
      catch(e){
        (0,i.tu)(u)}
      return u}
    async function m(e,t,r){
      let a=!(arguments.length>3)||void 0===arguments[3]||arguments[3],n={
        "Content-Type":"application/json"}
      ;
      return r&&(n.Authorization="Bearer ".concat(r)),v(e,{
        method:"POST",headers:n,body:JSON.stringify(t)}
      ,a,!r)}
    async function p(e,t){
      let r=!(arguments.length>2)||void 0===arguments[2]||arguments[2],a={
        }
      ;
      return t&&(a.Authorization="Bearer ".concat(t)),v(e,{
        method:"GET",headers:a}
      ,r,!t)}
    }
  ,89257:(e,t,r)=>{
    r.d(t,{
      Kq:()=>n,tu:()=>i}
    );
    let a=null;
    function n(e){
      a=e}
    function i(e,t){
      return(401===e.status||(null==t?void 0:t.errorType)==="AUTHENTICATION_REQUIRED")&&!!a&&(a(),!0)}
    }
  ,91577:(e,t,r)=>{
    r.d(t,{
      BT:()=>l,Wu:()=>d,ZB:()=>c,Zp:()=>o,aR:()=>s}
    );
    var a=r(38942),n=r(42062),i=r(85832);
    let o=n.forwardRef((e,t)=>{
      let{
        className:r,...n}
      =e;
      return(0,a.jsx)("div",{
        ref:t,className:(0,i.cn)("rounded-2xl border border-border/70 bg-card/90 text-card-foreground shadow-[0_18px_52px_-42px_rgba(64,43,27,0.5)] backdrop-blur-sm",r),...n}
      )}
    );
    o.displayName="Card";
    let s=n.forwardRef((e,t)=>{
      let{
        className:r,...n}
      =e;
      return(0,a.jsx)("div",{
        ref:t,className:(0,i.cn)("flex flex-col space-y-1.5 p-5 sm:p-6",r),...n}
      )}
    );
    s.displayName="CardHeader";
    let c=n.forwardRef((e,t)=>{
      let{
        className:r,...n}
      =e;
      return(0,a.jsx)("h3",{
        ref:t,className:(0,i.cn)("display-serif text-xl font-semibold leading-tight tracking-[0.02em]",r),...n}
      )}
    );
    c.displayName="CardTitle";
    let l=n.forwardRef((e,t)=>{
      let{
        className:r,...n}
      =e;
      return(0,a.jsx)("p",{
        ref:t,className:(0,i.cn)("text-sm text-muted-foreground",r),...n}
      )}
    );
    l.displayName="CardDescription";
    let d=n.forwardRef((e,t)=>{
      let{
        className:r,...n}
      =e;
      return(0,a.jsx)("div",{
        ref:t,className:(0,i.cn)("px-5 pb-5 sm:px-6 sm:pb-6",r),...n}
      )}
    );
    d.displayName="CardContent",n.forwardRef((e,t)=>{
      let{
        className:r,...n}
      =e;
      return(0,a.jsx)("div",{
        ref:t,className:(0,i.cn)("flex items-center px-5 pb-5 sm:px-6 sm:pb-6",r),...n}
      )}
    ).displayName="CardFooter"}
  ,94970:(e,t,r)=>{
    r.d(t,{
      A:()=>i}
    );
    var a=r(42062),n=r(69395);
    function i(){
      let[e,t]=(0,a.useState)(null),[r,i]=(0,a.useState)(!0),[o,s]=(0,a.useState)(!1);
      (0,a.useEffect)(()=>n.authClient.onAuthStateChange(e=>{
        t(e),s(!!e),i(!1)}
      ),[]);
      let c=async(e,t)=>await n.authClient.login(e,t),l=async(e,t,r)=>await n.authClient.register(e,t,r),d=async()=>{
        await n.authClient.logout()}
      ;
      return{
        user:e,isLoading:r,isAuthenticated:o,login:c,register:l,logout:d,getAuthHeaders:(0,a.useCallback)(()=>n.authClient.getAuthHeaders(),[]),refreshUser:(0,a.useCallback)(async()=>await n.authClient.refreshUser(),[])}
      }
    }
  ,99215:(e,t,r)=>{
    r.d(t,{
      W8:()=>i}
    );
    var a=r(69395),n=r(86503);
    async function i(){
      let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"divination_general";
      try{
        var t,r,i;
        let o=a.authClient.getSession();
        if(!(null==o?void 0:o.access_token))return{
          canAfford:!1,requiredCredits:0,availableCredits:0}
        ;
        let[s,c,l]=await Promise.all([(0,n.Vg)("/api/credits/balance"),(0,n.Vg)("/api/credits/rules"),(0,n.Vg)("/api/membership/status")]);
        if(!s.ok)throw Error("获取积分余额失败");
        c.ok;
        let d=await s.json(),u=(null==(t=d.credits)?void 0:t.available_credits)||d.available_credits||0,h=!1;
        try{
          if(l.ok){
            let e=await l.json();
            h=(null==(r=e.membership)?void 0:r.is_active)&&(null==(i=e.membership)?void 0:i.membership_type)==="pro"}
          }
        catch(e){
          }
        let f=100,y=0,v=0;
        try{
          let t=await c.json(),r=(t.rules||t.spendRules||[]).find(t=>t.action_type===e);
          r?h&&void 0!==r.pro_credits_amount&&null!==r.pro_credits_amount?(f=Math.abs(r.pro_credits_amount),v=(y=Math.abs(r.credits_amount))-f):r.credits_amount&&(f=Math.abs(r.credits_amount)):("offer_match"===e||"offer-match"===e)&&(y=299,h?(f=1,v=298):f=299)}
        catch(e){
          }
        return{
          canAfford:u>=f,requiredCredits:f,availableCredits:u,isPro:h,originalPrice:h&&y>0?y:void 0,discountSaved:h&&v>0?v:void 0}
        }
      catch(e){
        return{
          canAfford:!1,requiredCredits:0,availableCredits:0,error:e instanceof Error?e.message:"未知错误"}
        }
      }
    }
  }
]);
