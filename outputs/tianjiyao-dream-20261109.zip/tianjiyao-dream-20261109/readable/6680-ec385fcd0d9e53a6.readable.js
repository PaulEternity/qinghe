// 来源：REA 导出的公开生产脚本。仅格式化，保留打包模块与混淆变量；不是可独立运行的源码工程。
"use strict";
(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[6680],{
  19794:(e,t,r)=>{
    r.d(t,{
      Q:()=>h}
    );
    var a=r(38942),s=r(42062),n=r(32781),o=r(58649),l=r(86540),i=r(20692),d=r.n(i),c=r(86503),m=r(8464),u=r(37127),p=r(60272);
    function h(){
      let[e,t]=(0,s.useState)(null),[r,i]=(0,s.useState)(!0),h=(0,m.useLocale)(),x="zh-TW"===h,f=(e,t)=>x?(0,p.bb)(e):"zh"===h?e:t;
      (0,s.useEffect)(()=>{
        g()}
      ,[]);
      let g=async()=>{
        try{
          let r=await (0,c.Vg)("/api/membership/status");
          if(r.ok){
            var e;
            let a=await r.json();
            t(a.success&&(null==(e=a.membership)?void 0:e.is_active))}
          else t(!1)}
        catch(e){
          t(!1)}
        finally{
          i(!1)}
        }
      ;
      return r||e?null:(0,a.jsx)("div",{
        className:"mt-6 overflow-hidden rounded-xl border-2 border-yellow-300 bg-gradient-to-r from-yellow-50 via-amber-50 to-orange-50 dark:border-yellow-700 dark:from-yellow-950/30 dark:via-amber-950/30 dark:to-orange-950/30",children:(0,a.jsxs)("div",{
          className:"relative p-4",children:[(0,a.jsx)("div",{
            className:"absolute -right-6 -top-6 h-20 w-20 rounded-full bg-yellow-200/40 dark:bg-yellow-800/20"}
          ),(0,a.jsx)("div",{
            className:"absolute -bottom-4 -left-4 h-16 w-16 rounded-full bg-amber-200/40 dark:bg-amber-800/20"}
          ),(0,a.jsxs)("div",{
            className:"relative flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",children:[(0,a.jsxs)("div",{
              className:"flex items-start gap-3",children:[(0,a.jsx)("div",{
                className:"flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-yellow-400 to-amber-500 shadow-lg",children:(0,a.jsx)(n.A,{
                  className:"h-5 w-5 text-white"}
                )}
              ),(0,a.jsxs)("div",{
                children:[(0,a.jsxs)("h4",{
                  className:"flex items-center gap-2 font-bold text-gray-900 dark:text-gray-100",children:[f("开通Pro会员","Get Pro Membership"),(0,a.jsx)("span",{
                    className:"rounded-full bg-red-500 px-2 py-0.5 text-xs text-white",children:f("超值","Best Value")}
                  )]}
                ),(0,a.jsxs)("div",{
                  className:"mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-600 dark:text-gray-400",children:[(0,a.jsxs)("span",{
                    className:"flex items-center gap-1",children:[(0,a.jsx)(o.A,{
                      className:"h-3 w-3 text-yellow-500"}
                    ),f("所有服务仅1积分","All services 1 credit")]}
                  ),(0,a.jsxs)("span",{
                    className:"flex items-center gap-1",children:[(0,a.jsx)(o.A,{
                      className:"h-3 w-3 text-yellow-500"}
                    ),f("无限次使用","Unlimited use")]}
                  )]}
                )]}
              )]}
            ),(0,a.jsxs)(d(),{
              href:"/".concat(h,"/subscribe"),onClick:()=>(0,u.Q5)("membership_offer_opened",{
                placement:"reading_result"}
              ),className:"flex shrink-0 items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-yellow-500 to-amber-500 px-4 py-2 text-sm font-semibold text-white shadow-md transition-all hover:from-yellow-600 hover:to-amber-600 hover:shadow-lg active:scale-95",children:[(0,a.jsx)(n.A,{
                className:"h-4 w-4"}
              ),f("立即开通","Subscribe"),(0,a.jsx)(l.A,{
                className:"h-4 w-4"}
              )]}
            )]}
          )]}
        )}
      )}
    }
  ,30189:(e,t,r)=>{
    r.d(t,{
      r:()=>d}
    );
    var a=r(38942),s=r(42062),n=r(8464),o=r(85832),l=r(39908),i=r(60272);
    function d(e){
      let{
        className:t}
      =e,r=(0,n.useLocale)(),[d,c]=(0,s.useState)(0),m="zh-TW"===r,u=["翻阅典籍，寻找答案...","推演八卦，洞悉玄机...","参悟易理，明晰真相...","神思凝聚，天人合一...","窥探命理，揭示因果...","灵光闪现，答案将至...","拨开迷雾，真相渐明...","整理卦意，准备呈现..."],p="zh"===r||m?m?u.map(i.bb):u:["Reviewing classical references...","Tracing the hexagram patterns...","Interpreting the I Ching principles...","Aligning symbols and timing...","Comparing possible outcomes...","Refining the key judgment...","Clearing the remaining ambiguity...","Preparing the final reading..."];
      return(0,s.useEffect)(()=>{
        let e=setInterval(()=>{
          c(e=>(e+1)%p.length)}
        ,1800);
        return()=>clearInterval(e)}
      ,[p.length]),(0,a.jsxs)("div",{
        className:(0,o.cn)("flex items-center gap-3",t),"aria-live":"polite",children:[(0,a.jsx)(l.A,{
          className:"h-8 w-8 text-amber-500 animate-spin"}
        ),(0,a.jsx)("div",{
          className:"relative h-8 overflow-hidden",children:(0,a.jsx)("p",{
            className:"text-base font-medium text-amber-700 animate-in fade-in slide-in-from-bottom-2 duration-500 dark:text-amber-300",children:p[d]}
          ,d)}
        )]}
      )}
    }
  ,37127:(e,t,r)=>{
    r.d(t,{
      Pl:()=>d,Q5:()=>m,lg:()=>c}
    );
    let a="tianjiyao_first_touch_v1",s=new Set(["organic","paid","referral","direct"]),n=new Map([["bing.com","bing"],["google.","google"],["baidu.com","baidu"],["so.com","360"],["sogou.com","sogou"],["yahoo.","yahoo"],["duckduckgo.com","duckduckgo"],["yandex.","yandex"]]);
    function o(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:80;
      if("string"!=typeof e)return;
      let r=e.trim().replace(/[\r\n\t]+/g," ");
      return r?r.slice(0,t):void 0}
    function l(e){
      var t;
      let r=null==(t=o(e,120))?void 0:t.toLowerCase();
      return r&&/^[a-z0-9.-]+$/.test(r)?r:void 0}
    function i(e){
      var t;
      if(!e||"object"!=typeof e)return null;
      let r=s.has(e.channel)?e.channel:void 0,a=function(e){
        let t=o(e,180);
        return(null==t?void 0:t.startsWith("/"))?t:void 0}
      (e.landing_path);
      return r&&a?{
        channel:r,landing_path:a,...o(e.source)?{
          source:o(e.source)}
        :{
          }
        ,...o(e.medium)?{
          medium:o(e.medium)}
        :{
          }
        ,...o(e.campaign)?{
          campaign:o(e.campaign)}
        :{
          }
        ,...l(e.referrer_host)?{
          referrer_host:l(e.referrer_host)}
        :{
          }
        ,captured_at:"string"!=typeof(t=e.captured_at)||Number.isNaN(Date.parse(t))?new Date().toISOString():new Date(t).toISOString()}
      :null}
    function d(e){
      let t=function(e,t){
        let r="".concat(e,"="),a=t.split(";").map(e=>e.trim()).find(e=>e.startsWith(r));
        return a?a.slice(r.length):null}
      (a,(null!=e?e:"undefined"!=typeof document?document.cookie:"")||"");
      if(!t)return null;
      try{
        return i(JSON.parse(decodeURIComponent(t)))}
      catch(e){
        return null}
      }
    function c(){
      if("undefined"==typeof document)return null;
      let e=d();
      if(e)return e;
      let t=new URLSearchParams(window.location.search),r=(()=>{
        try{
          return document.referrer?new URL(document.referrer).hostname.toLowerCase():void 0}
        catch(e){
          return}
        }
      )(),s=o(t.get("utm_medium")||void 0),l=!!(t.get("gclid")||t.get("msclkid"))||/^(cpc|ppc|paid|display)$/i.test(s||""),c=r?function(e){
        for(let[t,r]of n)if(e===t||e.endsWith(".".concat(t))||e.includes(t))return r}
      (r):void 0,m=i({
        channel:l?"paid":c?"organic":r?"referral":"direct",source:o(t.get("utm_source")||void 0)||c||r,medium:s||(l?"paid":c?"organic":r?"referral":"direct"),campaign:o(t.get("utm_campaign")||void 0),landing_path:"".concat(window.location.pathname).concat(window.location.search),referrer_host:r,captured_at:new Date().toISOString()}
      );
      return m?(document.cookie="".concat(a,"=").concat(encodeURIComponent(JSON.stringify(m)),"; Path=/; Max-Age=").concat(2592e3,"; SameSite=Lax; Secure"),m):null}
    function m(e){
      let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{
        }
      ,r=Object.fromEntries(Object.entries(t).filter(e=>{
        let[,t]=e;
        return null!=t&&""!==t}
      )),a=window;
      if("function"==typeof a.gtag)return void a.gtag("event",e,r);
      a.dataLayer=a.dataLayer||[],a.dataLayer.push(["event",e,r])}
    }
  ,43240:(e,t,r)=>{
    r.d(t,{
      $v:()=>f,EO:()=>u,Lt:()=>i,Rx:()=>g,Zr:()=>b,ck:()=>h,r7:()=>x,tv:()=>d,wd:()=>p}
    );
    var a=r(38942),s=r(42062),n=r(35873),o=r(85832),l=r(2299);
    let i=n.bL,d=n.l9,c=n.ZL,m=s.forwardRef((e,t)=>{
      let{
        className:r,...s}
      =e;
      return(0,a.jsx)(n.hJ,{
        className:(0,o.cn)("fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",r),...s,ref:t}
      )}
    );
    m.displayName=n.hJ.displayName;
    let u=s.forwardRef((e,t)=>{
      let{
        className:r,...s}
      =e;
      return(0,a.jsxs)(c,{
        children:[(0,a.jsx)(m,{
          }
        ),(0,a.jsx)(n.UC,{
          ref:t,className:(0,o.cn)("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg",r),...s}
        )]}
      )}
    );
    u.displayName=n.UC.displayName;
    let p=e=>{
      let{
        className:t,...r}
      =e;
      return(0,a.jsx)("div",{
        className:(0,o.cn)("flex flex-col space-y-2 text-center sm:text-left",t),...r}
      )}
    ;
    p.displayName="AlertDialogHeader";
    let h=e=>{
      let{
        className:t,...r}
      =e;
      return(0,a.jsx)("div",{
        className:(0,o.cn)("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2",t),...r}
      )}
    ;
    h.displayName="AlertDialogFooter";
    let x=s.forwardRef((e,t)=>{
      let{
        className:r,...s}
      =e;
      return(0,a.jsx)(n.hE,{
        ref:t,className:(0,o.cn)("text-lg font-semibold",r),...s}
      )}
    );
    x.displayName=n.hE.displayName;
    let f=s.forwardRef((e,t)=>{
      let{
        className:r,...s}
      =e;
      return(0,a.jsx)("div",{
        ref:t,className:(0,o.cn)("text-sm text-muted-foreground",r),...s}
      )}
    );
    f.displayName=n.VY.displayName;
    let g=s.forwardRef((e,t)=>{
      let{
        className:r,...s}
      =e;
      return(0,a.jsx)(n.rc,{
        ref:t,className:(0,o.cn)((0,l.r)(),r),...s}
      )}
    );
    g.displayName=n.rc.displayName;
    let b=s.forwardRef((e,t)=>{
      let{
        className:r,...s}
      =e;
      return(0,a.jsx)(n.ZD,{
        ref:t,className:(0,o.cn)((0,l.r)({
          variant:"outline"}
        ),"mt-2 sm:mt-0",r),...s}
      )}
    );
    b.displayName=n.ZD.displayName}
  ,55864:(e,t,r)=>{
    r.d(t,{
      h2:()=>l,sX:()=>o}
    );
    var a=r(38942),s=r(33601),n=r(88082);
    let o="prose prose-sm max-w-none\n                  prose-p:my-1.5 prose-p:leading-7\n                  prose-ul:my-2 prose-ul:space-y-1\n                  prose-ol:my-2 prose-ol:space-y-1\n                  prose-li:my-0.5\n                  prose-h1:text-xl prose-h1:font-bold prose-h1:my-3 prose-h1:mb-2\n                  prose-h2:text-lg prose-h2:font-bold prose-h2:my-2.5 prose-h2:mb-1.5\n                  prose-h3:text-base prose-h3:font-semibold prose-h3:my-2 prose-h3:mb-1\n                  prose-strong:font-semibold\n                  prose-code:text-sm prose-code:bg-zinc-100 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded\n                  prose-pre:bg-zinc-100 prose-pre:p-3 prose-pre:rounded prose-pre:my-3\n                  prose-blockquote:border-l-4 prose-blockquote:border-zinc-300 prose-blockquote:pl-4 prose-blockquote:my-3\n                  prose-table:my-4 prose-table:w-full prose-table:text-sm\n                  prose-thead:bg-zinc-50\n                  prose-th:px-3 prose-th:py-2 prose-th:text-left prose-th:font-semibold prose-th:border prose-th:border-zinc-200\n                  prose-td:px-3 prose-td:py-2 prose-td:border prose-td:border-zinc-200\n                  prose-tr:even:bg-zinc-50/60\n                  text-zinc-800\n                  dark:prose-invert dark:text-zinc-200\n                  dark:prose-code:bg-zinc-900 dark:prose-pre:bg-zinc-900\n                  dark:prose-blockquote:border-zinc-700 dark:prose-thead:bg-zinc-900\n                  dark:prose-th:border-zinc-700 dark:prose-td:border-zinc-700 dark:prose-tr:even:bg-zinc-900/60\n                  [&_*]:break-words [&_*]:overflow-wrap-anywhere";
    function l(e){
      let{
        content:t,className:r=o}
      =e;
      return(0,a.jsx)(s.oz,{
        remarkPlugins:[n.A],className:r,children:t}
      )}
    }
  ,60312:(e,t,r)=>{
    r.d(t,{
      f:()=>m}
    );
    var a=r(38942),s=r(42062),n=r(2299),o=r(92360),l=r(15746),i=r(14265),d=r(8464),c=r(60272);
    function m(e){
      let{
        targetElementId:t,fileNamePrefix:r="divination-result",size:m="default",variant:u="outline",showIcon:p=!0,buttonText:h,addWatermark:x=!0,watermarkText:f=window.location.hostname,className:g="",disabled:b=!1,onBeforeDownload:v,onAfterDownload:y,onError:w}
      =e,[j,N]=(0,s.useState)(!1),k=(0,d.useLocale)(),z="zh-TW"===k,A="zh"===k||z,S=(e,t)=>z?(0,c.bb)(e):A?e:t,_=S("下载图片","Download Image"),C=S("生成中...","Generating..."),D=async()=>{
        let e=null;
        if(t){
          if(!(e=document.getElementById(t))){
            let e="未找到ID为 ".concat(t," 的元素");
            w?w(Error(e)):alert(S("下载失败：未找到指定元素","Download failed: Element not found"));
            return}
          }
        else e=document.querySelector("main")||document.querySelector('[role="main"]')||document.body;
        if(!e)return void(w?w(Error("未找到可截图的元素")):alert(S("下载失败：未找到内容区域","Download failed: Content area not found")));
        N(!0),v&&v();
        try{
          let t=await (0,i.Tf)(e,{
            quality:1,scale:2,backgroundColor:"#ffffff",style:{
              maxHeight:"none",overflow:"visible"}
            }
          );
          if(!x){
            let e=document.createElement("a");
            e.download="".concat(r,"-").concat(Date.now(),".png"),e.href=t,e.click(),y&&y();
            return}
          let a=new Image;
          a.src=t,await new Promise((e,t)=>{
            a.onload=e,a.onerror=t}
          );
          let s=document.createElement("canvas"),n=s.getContext("2d");
          if(!n)throw Error("无法创建 Canvas context");
          s.width=a.width,s.height=a.height,n.drawImage(a,0,0);
          let o=new Date().toLocaleDateString(z?"zh-TW":A?"zh-CN":"en-US");
          n.save();
          n.font="500 ".concat(20.8,"px -apple-system, BlinkMacSystemFont, sans-serif"),n.fillStyle="rgba(100, 116, 139, 0.4)",n.textAlign="right",n.textBaseline="bottom",n.fillText(f,s.width-30,s.height-30),n.font="400 ".concat(15.600000000000001,"px -apple-system, BlinkMacSystemFont, sans-serif"),n.fillStyle="rgba(148, 163, 184, 0.35)",n.fillText(o,s.width-30,s.height-30-20.8-5),n.restore();
          let l=s.toDataURL("image/png",1),d=document.createElement("a");
          d.download="".concat(r,"-").concat(Date.now(),".png"),d.href=l,d.click(),y&&y()}
        catch(e){
          w?w(e):alert(S("下载失败，请稍后重试","Download failed, please try again later"))}
        finally{
          N(!1)}
        }
      ;
      return(0,a.jsx)(n.$,{
        onClick:D,size:m,variant:u,disabled:b||j,className:g,"aria-label":S("下载图片","Download image"),title:S("将内容保存为图片","Save content as image"),children:j?(0,a.jsxs)(a.Fragment,{
          children:[p&&(0,a.jsx)(o.A,{
            size:16,className:"mr-1 animate-spin"}
          ),C]}
        ):(0,a.jsxs)(a.Fragment,{
          children:[p&&(0,a.jsx)(l.A,{
            size:16,className:"mr-1"}
          ),h||_]}
        )}
      )}
    }
  ,74588:(e,t,r)=>{
    r.d(t,{
      q:()=>c}
    );
    var a=r(38942);
    r(42062);
    var s=r(8464),n=r(36709),o=r(97442),l=r(20692),i=r.n(l),d=r(60272);
    function c(){
      let e=(0,s.useLocale)(),t="zh-TW"===e,r="zh"===e||t,l=e=>t?(0,d.bb)(e):e,c=r?[{
        quote:l("命理决定上限，努力决定下限"),subtext:l("格局是地图，不是枷锁")}
      ,{
        quote:l("风起时，随风而飞；风止时，安静等待"),subtext:l("顺势而为，趋利避害")}
      ]:[{
        quote:"Destiny sets the ceiling, effort sets the floor",subtext:"Fate is a map, not chains"}
      ,{
        quote:"Fly with the wind when it rises, wait quietly when it stops",subtext:"Flow with life, avoid harm, embrace good"}
      ],m=r?{
        title:l("深度阅读：命理的真正价值"),description:l("理解命理如何帮助我们更好地生活"),href:"/".concat(e,"/blog/true-value-of-destiny-reading")}
      :{
        title:"Deep Read: The True Value of Destiny Reading",description:"Understanding how destiny reading helps us live better",href:"/".concat(e,"/blog/true-value-of-destiny-reading")}
      ;
      return(0,a.jsxs)("div",{
        className:"mt-6 border-t border-border/50 pt-6",children:[(0,a.jsxs)("div",{
          className:"flex items-center gap-2 mb-4",children:[(0,a.jsx)(n.A,{
            size:18,className:"text-amber-500"}
          ),(0,a.jsx)("span",{
            className:"text-sm font-medium text-zinc-700 dark:text-zinc-200",children:r?l("命理智慧"):"Destiny Wisdom"}
          )]}
        ),(0,a.jsx)("div",{
          className:"grid gap-3 sm:grid-cols-2",children:c.map((e,t)=>(0,a.jsxs)("div",{
            className:"rounded-lg border border-amber-100/60 bg-gradient-to-br from-amber-50 to-orange-50 p-4 dark:border-amber-900/30 dark:bg-stone-900/50 dark:from-amber-950/30 dark:to-orange-950/20",children:[(0,a.jsxs)("p",{
              className:"text-sm font-medium leading-relaxed text-zinc-800 dark:text-zinc-200",children:['"',e.quote,'"']}
            ),(0,a.jsx)("p",{
              className:"mt-2 text-xs text-zinc-500 dark:text-zinc-400",children:e.subtext}
            )]}
          ,t))}
        ),(0,a.jsxs)(i(),{
          href:m.href,className:"group mt-4 flex items-start gap-3 rounded-lg border border-zinc-200 bg-white/40 p-4 transition-all hover:border-amber-300 hover:bg-amber-50/50 dark:border-stone-800 dark:bg-stone-900/30 dark:hover:border-amber-700/50 dark:hover:bg-amber-950/20",children:[(0,a.jsx)("div",{
            className:"rounded-lg bg-amber-100 p-2 transition-colors group-hover:bg-amber-200 dark:bg-amber-950/60 dark:group-hover:bg-amber-900/60",children:(0,a.jsx)(o.A,{
              size:20,className:"shrink-0 text-amber-600 dark:text-amber-400"}
            )}
          ),(0,a.jsxs)("div",{
            className:"flex-1",children:[(0,a.jsx)("h4",{
              className:"text-sm font-medium text-zinc-800 transition-colors group-hover:text-amber-700 dark:text-zinc-200 dark:group-hover:text-amber-300",children:m.title}
            ),(0,a.jsx)("p",{
              className:"mt-0.5 text-xs text-zinc-500 dark:text-zinc-400",children:m.description}
            )]}
          ),(0,a.jsx)("span",{
            className:"text-lg text-amber-500 transition-transform group-hover:translate-x-1 dark:text-amber-400",children:"→"}
          )]}
        )]}
      )}
    }
  ,83235:(e,t,r)=>{
    r.d(t,{
      Accordion:()=>i,AccordionContent:()=>m,AccordionItem:()=>d,AccordionTrigger:()=>c}
    );
    var a=r(38942),s=r(42062),n=r(6872),o=r(15672),l=r(85832);
    let i=n.bL,d=s.forwardRef((e,t)=>{
      let{
        className:r,...s}
      =e;
      return(0,a.jsx)(n.q7,{
        ref:t,className:(0,l.cn)("border-b last:border-b-0",r),...s}
      )}
    );
    d.displayName="AccordionItem";
    let c=s.forwardRef((e,t)=>{
      let{
        className:r,children:s,...i}
      =e;
      return(0,a.jsx)(n.Y9,{
        className:"flex",children:(0,a.jsxs)(n.l9,{
          ref:t,className:(0,l.cn)("flex flex-1 items-center justify-between py-4 text-left text-sm font-medium transition-all hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 [&[data-state=open]>svg]:rotate-180",r),...i,children:[s,(0,a.jsx)(o.A,{
            className:"h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200"}
          )]}
        )}
      )}
    );
    c.displayName=n.l9.displayName;
    let m=s.forwardRef((e,t)=>{
      let{
        className:r,children:s,...o}
      =e;
      return(0,a.jsx)(n.UC,{
        ref:t,className:"overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",...o,children:(0,a.jsx)("div",{
          className:(0,l.cn)("pb-4 pt-0 text-muted-foreground",r),children:s}
        )}
      )}
    );
    m.displayName=n.UC.displayName}
  ,86680:(e,t,r)=>{
    r.d(t,{
      A:()=>N,j:()=>j}
    );
    var a=r(38942),s=r(42062),n=r(2299),o=r(36709),l=r(72106),i=r(32258),d=r(63355),c=r(92360),m=r(30189),u=r(8464),p=r(60312),h=r(19794),x=r(74588),f=r(83235),g=r(55864),b=r(94970),v=r(85800),y=r(60272),w=r(43240);
    function j(){
      return(0,a.jsxs)("div",{
        className:"space-y-6",children:[(0,a.jsx)(x.q,{
          }
        ),(0,a.jsx)(h.Q,{
          }
        )]}
      )}
    let N=function(e){
      var t;
      let{
        completion:r,isLoading:h,onCompletion:x,error:N,errorHelp:k,onRestart:z,screenshotElementId:A,creditCost:S,isShowTipsCard:_=!0,hasFollowUpSection:C=!1,questionId:D,onDeleteRecord:R}
      =e,T=(0,s.useRef)(null),[E,I]=(0,s.useState)(!1),[L,q]=(0,s.useState)(!1),[W,O]=(0,s.useState)(!1),[U,F]=(0,s.useState)(!1),{
        user:P,getAuthHeaders:$}
      =(0,b.A)(),B=(0,u.useLocale)(),H="zh-TW"===B,J="zh"===B||H,M=e=>H?(0,y.bb)(e):e,V=async()=>{
        if(!D){
          null==R||R(),F(!0),q(!1);
          return}
        O(!0);
        try{
          (await fetch((0,v.c_)("/api/qa-records"),{
            method:"POST",headers:$(),body:JSON.stringify({
              action:"delete",questionId:D,userId:null==P?void 0:P.id}
            )}
          )).ok&&(F(!0),q(!1),null==R||R())}
        catch(e){
          }
        finally{
          O(!1)}
        }
      ;
      (0,s.useEffect)(()=>{
        I(h)}
      ,[h]),(0,s.useEffect)(()=>{
        E&&requestAnimationFrame(()=>{
          T.current&&T.current.scrollHeight!==T.current.clientHeight+T.current.scrollTop&&T.current.scrollTo(0,T.current.scrollHeight)}
        )}
      );
      let Z=!C&&!h&&r&&!N&&_,Q=e=>(0,a.jsx)(g.h2,{
        content:e}
      ),G=h||!r||N?null:function(e){
        let t=e.split("\n"),r=[],a=[],s=null;
        for(let e of t){
          let t=function(e){
            let t=e.replace(/^#{1,6}\s*/,"").trim().replace(/[：:]\s*$/,"");
            return t?/30秒(?:结论|結論)|(?:结论|結論)提要/.test(t)?{
              key:"summary",title:t}
            :/(?:主体|主體|详细|詳細|深度)(?:解读|解讀)/.test(t)?{
              key:"body",title:t}
            :/(?:关键|關鍵)年份与(?:行动|行動)|(?:关键|關鍵)年份与落点|(?:关键|關鍵)年份與落點|(?:关键|關鍵)年份/.test(t)?{
              key:"years",title:t}
            :null:null}
          (e);
          if(t){
            s&&(s.content=s.content.trim(),a.push(s)),s={
              key:t.key,title:t.title,content:""}
            ;
            continue}
          s?s.content+="".concat(e,"\n"):r.push(e)}
        return s&&(s.content=s.content.trim(),a.push(s)),{
          preface:r.join("\n").trim(),sections:a.filter(e=>e.content)}
        }
      (r),Y=!!(G&&G.sections.some(e=>"summary"===e.key));
      return(0,a.jsxs)("div",{
        className:"legacy-dark-content w-full mt-3 sm:mt-6",children:[h&&(0,a.jsx)("div",{
          className:"mb-4 rounded-xl border border-amber-200/70 bg-gradient-to-r from-amber-50 via-white to-orange-50 p-3 sm:p-4 shadow-sm dark:border-amber-700/60 dark:from-amber-950/20 dark:via-card dark:to-orange-950/10",children:(0,a.jsxs)("div",{
            className:"flex flex-col gap-2",children:[(0,a.jsx)(m.r,{
              className:"min-h-8"}
            ),(0,a.jsx)("p",{
              className:"text-xs text-amber-800 dark:text-amber-300",children:J?"正在翻阅典籍、比对卦例并整理更清晰的解读，请稍候。":"Reviewing classical references, comparing hexagram cases, and preparing a clearer reading. Please wait."}
            )]}
          )}
        ),(0,a.jsxs)("div",{
          ref:T,onScroll:e=>(function(e){
            if(!h)return;
            let t=e.scrollTop+e.clientHeight>=e.scrollHeight-15;
            t!==E&&I(t)}
          )(e.currentTarget),className:"overflow-auto rounded-md border-0 p-0 shadow bg-card text-card-foreground text-left",style:{
            wordBreak:"break-word",overflowWrap:"break-word",wordWrap:"break-word",maxWidth:"100%",minWidth:0}
          ,children:[N?(0,a.jsxs)("div",{
            className:"text-destructive p-3",children:["ಠ_ಠ 请求出错了！",(0,a.jsx)("br",{
              }
            ),N,k?(0,a.jsx)("div",{
              className:"mt-3 text-left",children:k}
            ):null]}
          ):(0,a.jsx)("div",{
            className:"w-full text-foreground",style:{
              wordBreak:"break-word",overflowWrap:"anywhere"}
            ,children:(0,a.jsx)("div",{
              className:"overflow-x-auto",children:Y&&G?(0,a.jsxs)("div",{
                className:"space-y-3 sm:space-y-4",children:[G.preface&&Q(G.preface),G.sections.filter(e=>"summary"===e.key).map(e=>(0,a.jsxs)("div",{
                  className:"rounded-xl border border-[oklch(var(--module-accent,var(--brand-copper))/0.3)] bg-gradient-to-br from-[oklch(var(--module-accent,var(--brand-copper))/0.08)] via-card to-[oklch(var(--module-accent,var(--brand-copper))/0.03)] p-3 sm:p-4 shadow-sm",children:[(0,a.jsxs)("div",{
                    className:"mb-2 flex items-center gap-2 text-sm font-semibold text-[oklch(var(--module-accent,var(--brand-copper)))]",children:[(0,a.jsx)(o.A,{
                      className:"h-4 w-4"}
                    ),e.title]}
                  ),(0,a.jsx)("div",{
                    className:"rounded-lg bg-card/70 px-2.5 py-2 sm:px-3 sm:py-2.5 text-foreground/90",children:Q(e.content)}
                  )]}
                ,e.key)),(0,a.jsx)(f.Accordion,{
                  type:"multiple",defaultValue:["body","years"],className:"rounded-xl border border-border/70 bg-card/60 px-2 sm:px-4",children:G.sections.filter(e=>"summary"!==e.key).map(e=>(0,a.jsxs)(f.AccordionItem,{
                    value:e.key,className:"border-border/60",children:[(0,a.jsx)(f.AccordionTrigger,{
                      className:"text-sm font-semibold text-foreground hover:no-underline py-3",children:e.title}
                    ),(0,a.jsx)(f.AccordionContent,{
                      className:"text-foreground/90 leading-relaxed px-0.5 sm:px-1 pb-3",children:Q(e.content)}
                    )]}
                  ,e.key))}
                )]}
              ):(0,a.jsx)("div",{
                className:"px-1 py-1 sm:px-2",children:Q(r)}
              )}
            )}
          ),(0,a.jsxs)("div",{
            className:"mt-4 flex flex-wrap gap-2 border-t border-border/50 pt-4",children:[!h&&N&&(0,a.jsxs)(n.$,{
              onClick:x,size:"sm",variant:"outline",children:[(0,a.jsx)(l.A,{
                size:16,className:"mr-1"}
              ),J?M("重新生成"):"Regenerate",S?" (".concat(S," ").concat(J?M("积分"):"credits",")"):""]}
            ),!h&&r&&!N&&(0,a.jsx)(p.f,{
              targetElementId:A||(null==(t=T.current)?void 0:t.id),size:"sm",variant:"outline",fileNamePrefix:"ai-interpretation",buttonText:J?M("保存为图片"):"Save as Image"}
            ),!h&&r&&!N&&(D||R)&&(U?(0,a.jsxs)("span",{
              className:"inline-flex items-center gap-1 text-xs text-muted-foreground self-center px-2",children:[(0,a.jsx)(i.A,{
                className:"h-3.5 w-3.5 text-green-600"}
              ),J?M("已删除本次记录"):"Reading deleted"]}
            ):(0,a.jsxs)(n.$,{
              onClick:()=>q(!0),size:"sm",variant:"outline",className:"text-red-600 hover:bg-red-50 hover:text-red-700 dark:hover:bg-red-950/40",children:[(0,a.jsx)(d.A,{
                size:15,className:"mr-1"}
              ),J?M("删除本次记录"):"Delete Reading"]}
            ))]}
          )]}
        ),(0,a.jsx)(w.Lt,{
          open:L,onOpenChange:q,children:(0,a.jsxs)(w.EO,{
            children:[(0,a.jsxs)(w.wd,{
              children:[(0,a.jsx)(w.r7,{
                children:J?M("确认删除本次占卜记录？"):"Delete this reading?"}
              ),(0,a.jsx)(w.$v,{
                children:J?M("删除后将不会保留在历史记录中，此操作无法撤销。"):"This reading will be removed from your history and cannot be recovered."}
              )]}
            ),(0,a.jsxs)(w.ck,{
              children:[(0,a.jsx)(w.Zr,{
                disabled:W,children:J?M("取消"):"Cancel"}
              ),(0,a.jsx)(w.Rx,{
                onClick:V,disabled:W,className:"bg-red-600 text-white hover:bg-red-700",children:W?(0,a.jsxs)(a.Fragment,{
                  children:[(0,a.jsx)(c.A,{
                    className:"mr-2 h-4 w-4 animate-spin"}
                  ),J?M("删除中..."):"Deleting..."]}
                ):(0,a.jsxs)(a.Fragment,{
                  children:[(0,a.jsx)(d.A,{
                    className:"mr-2 h-4 w-4"}
                  ),J?M("确认删除"):"Delete"]}
                )}
              )]}
            )]}
          )}
        ),Z&&(0,a.jsx)(j,{
          }
        )]}
      )}
    }
  }
]);
